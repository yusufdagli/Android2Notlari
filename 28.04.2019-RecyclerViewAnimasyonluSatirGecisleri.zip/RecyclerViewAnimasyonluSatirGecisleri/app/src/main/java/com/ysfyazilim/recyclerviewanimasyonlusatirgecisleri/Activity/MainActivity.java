package com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;


import com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.Adapter.AdapterUyeler;
import com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.Model.Uyeler;
import com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.R;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    AdapterUyeler adapterUyeler;
    ArrayList<Uyeler> uyeler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        uyeler=new ArrayList<>();
        doldur(50);
        adapterUyeler = new AdapterUyeler(getApplicationContext(),uyeler);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapterUyeler);
    }

    public void doldur(int sayi)
    {
        for (int i = 0; i<sayi; i++) {
            uyeler.add(new Uyeler(
                    "http://3.bp.blogspot.com/-SMJy8C7Ph_Y/UDxrp4fF-FI/AAAAAAAAFnI/9r-t1I_bmUA/s1600/Facebook+Men+Profile+Pictures+(31).jpg",
                    "Ad Soyad"+i,
                    "Email"+i
            ));

        }
    }

}
