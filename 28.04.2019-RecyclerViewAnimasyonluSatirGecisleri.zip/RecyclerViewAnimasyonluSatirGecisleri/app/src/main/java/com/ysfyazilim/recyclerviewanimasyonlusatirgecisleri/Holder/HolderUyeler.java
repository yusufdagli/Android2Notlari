package com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.Holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.R;

public class HolderUyeler extends RecyclerView.ViewHolder {
    public ImageView ivResim;
    public TextView txtemail,txtad;



    public HolderUyeler(@NonNull View itemView) {
        super(itemView);
        ivResim = itemView.findViewById(R.id.profilResim);
        txtemail = itemView.findViewById(R.id.txtEmail);
        txtad = itemView.findViewById(R.id.txtAd);
    }
}
