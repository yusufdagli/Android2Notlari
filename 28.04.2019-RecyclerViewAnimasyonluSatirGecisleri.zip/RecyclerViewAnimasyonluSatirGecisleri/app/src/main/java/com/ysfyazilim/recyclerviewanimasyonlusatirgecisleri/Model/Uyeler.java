package com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.Model;

public class Uyeler {
    private String profilResmi;
    private String ad;
    private String email;

    public Uyeler() {
    }

    public Uyeler(String profilResmi, String ad, String email) {
        this.profilResmi = profilResmi;
        this.ad = ad;
        this.email = email;
    }

    public String getProfilResmi() {
        return profilResmi;
    }

    public void setProfilResmi(String profilResmi) {
        this.profilResmi = profilResmi;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
