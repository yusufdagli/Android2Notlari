package com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.bumptech.glide.Glide;
import com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.Holder.HolderUyeler;
import com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.Model.Uyeler;
import com.ysfyazilim.recyclerviewanimasyonlusatirgecisleri.R;

import java.util.ArrayList;

public class AdapterUyeler extends RecyclerView.Adapter<HolderUyeler> {
    Context context;
    ArrayList<Uyeler> uyeler = new ArrayList<>();

    public AdapterUyeler() {
    }

    public AdapterUyeler(Context context, ArrayList<Uyeler> uyeler) {
        this.context = context;
        this.uyeler = uyeler;
    }

    @NonNull
    @Override
    public HolderUyeler onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_layout,viewGroup,false);
        return new HolderUyeler(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderUyeler holderUyeler, int i) {
        Animation animation = AnimationUtils.loadAnimation(holderUyeler.itemView.getContext(),R.anim.item_animation_fall_down);
        holderUyeler.itemView.startAnimation(animation);
        holderUyeler.txtad.setText(uyeler.get(i).getAd());
        holderUyeler.txtemail.setText(uyeler.get(i).getEmail());
        Glide.with(context).load(uyeler.get(i).getProfilResmi()).into(holderUyeler.ivResim);
    }

    @Override
    public int getItemCount() {
        return uyeler.size();
    }
}
