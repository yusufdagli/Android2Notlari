package com.ysfyazilim.recyclerviewlistgorunumu.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.ysfyazilim.recyclerviewlistgorunumu.Adapter.AdapterMekan;
import com.ysfyazilim.recyclerviewlistgorunumu.Model.GezilecekMekanlar;
import com.ysfyazilim.recyclerviewlistgorunumu.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<GezilecekMekanlar> mekanlar = new ArrayList<>();
    AdapterMekan adapterMekan;

    public void mekanlariGetir(){
        mekanlar.add(new GezilecekMekanlar(
                1,
                "isim",
                "acıklama",
                "adres",
                "https://cdn.islamansiklopedisi.org.tr/madde/4/ayasofya-2.jpg"
        ));
        mekanlar.add(new GezilecekMekanlar(
                2,
                "isim",
                "acıklama",
                "adres",
                "https://cdn.islamansiklopedisi.org.tr/madde/4/ayasofya-2.jpg"
        ));
        mekanlar.add(new GezilecekMekanlar(
                3,
                "isim",
                "acıklama",
                "adres",
                "https://cdn.islamansiklopedisi.org.tr/madde/4/ayasofya-2.jpg"
        ));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        mekanlariGetir();
        adapterMekan = new AdapterMekan(getApplicationContext(),mekanlar);
        /*adapterMekan.satir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Tıklanan indis",Toast.LENGTH_LONG).show();

            }
        }); */
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapterMekan);




    }
}
