package com.ysfyazilim.recyclerviewlistgorunumu.Model;

public class GezilecekMekanlar {
    private int id;
    private String isim;
    private String aciklama;
    private String adres;
    private String resim;

    public GezilecekMekanlar() {
    }

    public GezilecekMekanlar(int id, String isim, String aciklama, String adres, String resim) {
        this.id = id;
        this.isim = isim;
        this.aciklama = aciklama;
        this.adres = adres;
        this.resim = resim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

    public String getAdres() {
        return adres;
    }

    public void setAdres(String adres) {
        this.adres = adres;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }
}
