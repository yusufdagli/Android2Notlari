package com.ysfyazilim.recyclerviewlistgorunumu.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.ysfyazilim.recyclerviewlistgorunumu.Holder.ViewHolderMekan;
import com.ysfyazilim.recyclerviewlistgorunumu.Model.GezilecekMekanlar;
import com.ysfyazilim.recyclerviewlistgorunumu.R;

import java.util.ArrayList;

public class AdapterMekan extends RecyclerView.Adapter<ViewHolderMekan> {
    private Context context;
    private ArrayList<GezilecekMekanlar> gezilecekMekanlar;
    public View satir;

    public AdapterMekan() {
    }

    public AdapterMekan(Context context, ArrayList<GezilecekMekanlar> gezilecekMekanlar) {
        this.context = context;
        this.gezilecekMekanlar = gezilecekMekanlar;
    }



    @NonNull
    @Override
    public ViewHolderMekan onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.mekan_satirgoruntusu,null);
        /*

        Metodun geri dönüş tipi ViewHolderMekan sınıfı tipindedir.Bu nesne View'dir.
        onCreateViewHolder metodu satır görüntüsünün üretilme zamanını ifade eder.
        */

        return new  ViewHolderMekan(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderMekan viewHolderMekan, int i) {
       viewHolderMekan.tvAdres.setText(gezilecekMekanlar.get(i).getAdres());
       viewHolderMekan.tvBaslik.setText(gezilecekMekanlar.get(i).getIsim());
        Glide
                .with(context)
                .load(gezilecekMekanlar.get(i).getResim())
                .into(viewHolderMekan.ivResim);
        satir = viewHolderMekan.itemView;


    }

    @Override
    public int getItemCount() {
        return gezilecekMekanlar.size();
    }
}
